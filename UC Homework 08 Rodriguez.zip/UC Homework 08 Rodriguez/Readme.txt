UC Homework 08 Rodriguez 10/19/2015


*NOTE* This is a re-submission. I fixed the exception you were seeing int he last submission. 

This is my current working copy for this homework assignment. The output is not 100% like the example
slides. I still need to switch the parse stack output to tokens rather then literal values, as is the 
example in the slides. 
Attached is input files. Program reads hw8input.txt file and outputs to the console

hw7input.txt contains micro grammar
hw8input.txt contains the text file to be read. 
Contains Java 8 features. 

All files need to me compiled. Homework.java contains main. 