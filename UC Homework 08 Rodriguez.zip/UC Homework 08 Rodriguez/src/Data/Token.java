package Data;

public enum Token {
	READSYM,
	WRITESYM,
	ENDSYM,
	BEGINSYM
}
