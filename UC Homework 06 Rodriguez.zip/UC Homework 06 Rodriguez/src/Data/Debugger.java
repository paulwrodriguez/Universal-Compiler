package Data;


public class Debugger {
	public static final boolean DEBUG = false;
	public static final int TERMINATE = 0;
	public static final int FORDEBUG = 1;
	public static final int ENDPROGRAM = 2;
	public static final int UNKNOWN = 99;

	public static void ERROR(String s, int code) throws ErrorException{
		if(code == TERMINATE){
			throw new ErrorException("ErrorException encountered: " +s);
		}
		else if(code == FORDEBUG){
			System.out.println(s);
		}
		else if(code == ENDPROGRAM){
			System.out.println(s);
			System.exit(-ENDPROGRAM);
		}
	}
	public static void ERRORNOTHROW(String s, int code){
		if(code == FORDEBUG){
			System.out.println(s);
		}
		else if(code == ENDPROGRAM){
			System.out.println(s);
			System.exit(-ENDPROGRAM);
		}
		else {
			System.out.println("Invalid use of ERRORNOTHROW. Program End");
			System.exit(-UNKNOWN);
		}
	}
}

