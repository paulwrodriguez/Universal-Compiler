UC Homework 11 Rodriguez 11/16/2015

Attached is input and output files. Program reads hw3input.txt file and outputs to hw3output.txt
file and standard output. The program outputs where the error was encountered and what symbols
were skipped in order to continue parsing. 

Files:
hw3input.txt : contains program to be read
hw3output.txt: contains assembly produced by read program 


All files need to me compiled. Homework.java contains main. 