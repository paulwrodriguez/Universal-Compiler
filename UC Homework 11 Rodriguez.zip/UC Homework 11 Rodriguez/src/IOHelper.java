import java.io.PrintWriter;


public class IOHelper {
	public Scanner sc;
	public PrintWriter pw;
	public PrintWriter[] pwArray;
	public static final int SYS = 1;
	public static final int LOG = 2;
	public static final int SYNTAXERROR = 3; 
	
	IOHelper(Scanner sc, PrintWriter pw) {
		this.sc = sc;
		this.pw = pw;
	}
	IOHelper(Scanner sc, PrintWriter ... pwArray) {
		this.sc = sc;
		this.pw = pwArray[0]; // TODO fix this
		this.pwArray = pwArray;
	}
	public void println(int out, String data){
		
		switch(out){
		case SYS:
//			pwArray[SYS].println(data);
//			pwArray[SYS].flush();
			break;
		case LOG:
			pwArray[SYS].println(data);
			pwArray[SYS].flush();
			break;
		case SYNTAXERROR:
			pwArray[SYS].println(data);
			pwArray[SYS].flush();
			break;
		default:
			System.out.println("Error: IOHelper.Println -> " + out + " > " + pwArray.length);
		}
		
		return;
	}
	void close() {
		if(pw != null) {
			pw.close();
		}
		if(pwArray != null) {
			for(int i = 0; i < pwArray.length; ++i) {
				if(i == SYS) {
					pwArray[i].flush();
					continue;
				}
				pwArray[i].close();
				
			}
		}
	}
	
}
