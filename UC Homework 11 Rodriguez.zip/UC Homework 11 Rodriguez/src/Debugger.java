
public class Debugger {
	public static final boolean DEBUG = false;
}
