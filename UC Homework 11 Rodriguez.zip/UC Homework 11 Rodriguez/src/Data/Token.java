package Data;

public enum Token {
	 /*Constants*/

	
	 /*Reserved Words*/
	BeginSym,
	WriteSym,
	ReadSym,
	EndSym,
	
	 /*Variable*/
	Id, 
	IntLiteral,
	
	 /*Character Set*/
	LParen, 
	Colon, 
	SemiColon, 
	RParen, 
	Comma, 
	PlusOp, 
	MinusOp, 
	AssignOp,
	
	EofSym;	
}

