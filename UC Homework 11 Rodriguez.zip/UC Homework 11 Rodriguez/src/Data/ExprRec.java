package Data;


public class ExprRec {

	public ExprRec(ExprKind ek) {
		this.kind = ek;
	}
	public ExprRec(boolean getTempData) { 
		if(getTempData) {
			/*TODO something*/
			kind = ExprKind.TempExpr;
		}
	}
	public String name() {
		return name;
	}
	public ExprKind Kind() {
		return kind;
	}
	public String getVal() {
		return "" + val;
	}
	public void insert(String data) {
		name = data;
	}
	public ExprKind kind;
	public String name;
	public int val;
	
	
}
