package Data;

import java.util.ArrayList;
import java.util.Arrays;

public class TerminalSet {
	private ArrayList<Token> tokens;
	
	public TerminalSet(Token ... _tokens){
		tokens = new ArrayList<Token>(Arrays.asList(_tokens));
	}
	public TerminalSet() {
		tokens = new ArrayList<Token>();
	}
	public boolean contains(Token t){
		for(Token i : tokens){
			if(i == t){
				return true;
			}
		}
		return false;
	}
	public TerminalSet union(TerminalSet right) {
		TerminalSet result = new TerminalSet();
		result.addAll(this);
		result.addAll(right);
		return result;
		
	}
	public void addAll(TerminalSet right) {
		tokens.addAll(right.tokens);
	}
}
