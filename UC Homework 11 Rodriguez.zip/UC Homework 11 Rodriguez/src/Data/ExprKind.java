package Data;

public enum ExprKind {
	IdExpr, LiteralExpr, TempExpr;
}
