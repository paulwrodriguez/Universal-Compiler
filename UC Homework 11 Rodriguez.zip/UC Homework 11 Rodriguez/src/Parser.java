import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Locale;

import Data.ExprRec;
import Data.OpRec;
import Data.TerminalSet;
import Data.Token;


public class Parser {

	private static final boolean OUTPUT_PARSE_LIST = true;
	private Scanner sc;
	private PrintWriter pw;
	private IOHelper io;
	private SemanticParser sp;
	private ArrayList<String> parserList;
	private ArrayList<String> tokensSkipped;
	
	
	Parser(IOHelper io) {
		this.io = io;
		this.sc = io.sc;
		this.pw = io.pw;
		this.parserList = new ArrayList<String>();
		this.tokensSkipped = new ArrayList<String>();
		sp = new SemanticParser(this.io, this.sc);
	}

	 /*SystemGoal*/
	private void SystemGoal() throws Exception {
		io.println(IOHelper.SYS,"Call SystemGoals");
		Program();
		Match(Token.EofSym);
		sp.Finish();
	}
	 /*Program*/
	private void Program() throws Exception {
		sp.Start();
		io.println(IOHelper.SYS,"Call Program");
		Check_Input(new TerminalSet(Token.BeginSym),
					new TerminalSet(Token.EofSym),
					new TerminalSet(Token.EofSym));
		
		Match(Token.BeginSym);
		StatementList();
		Match(Token.EndSym);
	}
	 /*StatementList*/
	private void StatementList() throws Exception {
		io.println(IOHelper.SYS,"Call StatementList");
		Check_Input(new TerminalSet(Token.Id, Token.ReadSym, Token.WriteSym),
				new TerminalSet(Token.EndSym),
				new TerminalSet(Token.EofSym));
		Statement();
		switch(NextToken()){
		case Id:
		case ReadSym:
		case WriteSym: 
			StatementList();
			break;
			default:
				return;
		}
	}
	 /*Statement*/
	private void Statement() throws Exception{
		Check_Input(new TerminalSet(Token.Id, Token.ReadSym, Token.WriteSym),
				new TerminalSet(Token.EndSym),
				new TerminalSet(Token.EofSym));
		/* Semantic Parser Variables */
		ExprRec Identifier = new ExprRec(true);
		ExprRec  Expr = new ExprRec(true);
		switch(NextToken()) {
		case Id:
			io.println(IOHelper.SYS,"Call Statment");
			Ident(Identifier);
			Match(Token.AssignOp);
			Expr = Expression(Expr);
			sp.Assign(Identifier, Expr);
			Match(Token.SemiColon);
			break;
		case ReadSym:
			io.println(IOHelper.SYS,"Call Statment");
			Match(Token.ReadSym);
			Match(Token.LParen);
			IdList();
			Match(Token.RParen);
			Match(Token.SemiColon);
			break;
		case WriteSym:
			io.println(IOHelper.SYS,"Call Statment");
			Match(Token.WriteSym);
			Match(Token.LParen);
			ExprList();;
			Match(Token.RParen);
			Match(Token.SemiColon);
			break;
			default:
				SyntaxError(NextToken());
				break;			
		}
	}
	 /*IdList*/
	private void IdList() throws Exception{
		Check_Input(new TerminalSet(Token.Id),
				new TerminalSet(Token.RParen),
				new TerminalSet(Token.EofSym));
		ExprRec Identifier = new ExprRec(true);
		io.println(IOHelper.SYS,"Call IdList");
		Ident(Identifier);
		sp.ReadId(Identifier);
		if(NextToken() == Token.Comma) {
			Match(Token.Comma);
			IdList();
		}
		else{
			return;
		}
	}
	 /*ExprList*/
	private void ExprList() throws Exception {
		Check_Input(new TerminalSet(Token.Id, Token.IntLiteral, Token.LParen),
				new TerminalSet(Token.RParen),
				new TerminalSet(Token.EofSym));
		ExprRec Expr = new ExprRec(true);
		io.println(IOHelper.SYS,"Call ExprList");
		Expression(Expr);
		sp.WriteExpr(Expr);
		if(NextToken() == Token.Comma) {
			Match(Token.Comma);
			ExprList();
		}
		else{
			return;
		}
	}
	 /*Expression*/
	private ExprRec Expression(ExprRec Result) throws Exception {
		Check_Input(new TerminalSet(Token.Id, Token.IntLiteral, Token.LParen),
				new TerminalSet(Token.RParen, Token.Comma, Token.SemiColon),
				new TerminalSet(Token.EndSym));
		ExprRec LeftOperand = new ExprRec(true);
		ExprRec RightOperand = new ExprRec(true);
		OpRec Op = new OpRec();
		io.println(IOHelper.SYS,"Call Expression");
		Primary(LeftOperand);
		if(NextToken() == Token.PlusOp || NextToken() == Token.MinusOp) {
			AddOp(Op);
			RightOperand = Expression(RightOperand);
			Result = sp.GenInfix(LeftOperand, Op, RightOperand);
		}
		else {
			Result = LeftOperand;
		}
		return Result; 
	}
	 /*Primary*/
	private void Primary(ExprRec Result) throws Exception{
		Check_Input(new TerminalSet(Token.Id, Token.IntLiteral, Token.LParen),
				new TerminalSet(Token.Comma, Token.SemiColon, Token.RParen, Token.PlusOp, Token.MinusOp),
				new TerminalSet(Token.EofSym));
		switch(NextToken()) {
		case LParen:
			io.println(IOHelper.SYS,"Call Primary");
			Match(Token.LParen);
			Expression(Result);
			Match(Token.RParen);
			break;
		case Id:
			io.println(IOHelper.SYS,"Call Primary");
			Ident(Result);
			break;
		case IntLiteral:
			io.println(IOHelper.SYS,"Call Primary");
			Match(Token.IntLiteral);
			sp.ProcessLiteral(Result);
			break;
			default:
				SyntaxError(NextToken());
				break;
		}
	}
	 /*Ident*/
	private void Ident(ExprRec Result) throws Exception {
		Check_Input(new TerminalSet(Token.Id),
				new TerminalSet(Token.Comma, Token.SemiColon, Token.RParen, Token.PlusOp, Token.MinusOp, Token.AssignOp),
				new TerminalSet(Token.EofSym));
		io.println(IOHelper.SYS,"Call Ident");
		Match(Token.Id);
		sp.ProcessId(Result);
	}
	
	 /*AddOp*/
	private void AddOp(OpRec Op) throws Exception{
		Check_Input(new TerminalSet(Token.PlusOp, Token.MinusOp),
				new TerminalSet(Token.Id, Token.IntLiteral, Token.LParen),
				new TerminalSet(Token.EofSym));
		switch(NextToken()){
		case PlusOp:
			io.println(IOHelper.SYS,"Call AddOp");
			Match(Token.PlusOp);
			sp.ProcessOp(Op);
			break;
		case MinusOp:
			io.println(IOHelper.SYS,"Call AddOp");
			Match(Token.MinusOp);
			sp.ProcessOp(Op);
			break;
			default:
				SyntaxError(NextToken());
				break;
		}
	}
	private Token NextToken() {
		try {
			return sc.NextToken();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERROR: Parser.nextToken");
			return null;
		}
	}
	public void parse() throws Exception {
		SystemGoal();
	}
	// Post: 
	private void Check_Input(TerminalSet validSet, TerminalSet followSet, TerminalSet HeaderSet) throws Exception{
		Token skipToken;
		if(validSet.contains(NextToken())){
			io.println(IOHelper.SYS, "inside if for check_intput for " + NextToken());
			return;
		}
		else {
			io.println(IOHelper.SYS, "inside else for check_intput for " + NextToken());
			SyntaxError(NextToken());
			while(!validSet.union(followSet).union(HeaderSet).contains(NextToken())){
				skipToken = sc.Scan();
				io.println(IOHelper.SYS, "Inside while for check_input skiping"  + skipToken);
			}
		}
	}
	
	 /*Post: Call SyntaxError if t does not match next token*/
	public void Match(Token legalToken) {
		Token currentToken;
		io.println(IOHelper.SYS,"Call Match(" + legalToken.name() + ") ");
		try {
			if(NextToken() == legalToken){
				parserList.add(sc.getTokenToString());
				currentToken = sc.Scan();
			}
			else {
				currentToken = legalToken;
				SyntaxError(legalToken); // Error Correction and Parser Restart
				if(legalToken == Token.SemiColon || legalToken == Token.EofSym) {
					currentToken = sc.Scan();
					while(currentToken != legalToken){
						tokensSkipped.add(sc.getTokenToString());
						io.println(IOHelper.SYNTAXERROR, "Error recovery skipping " + sc.getTokenToString());
						currentToken = sc.Scan();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private void SyntaxError(String s) throws Exception {
		String output = "Error : ";
		String spaces = "";
		for(String i : parserList)  {
			output += i + ' ';
		}
		for(int i = 0; i < output.length(); ++i){
			spaces += ' ';
		}
		sc.NextToken();
		output += '[' + s + ']' + ' ' +  sc.getTokenToString();
		output += '\n'+ spaces +  "^  at this point  ";
		
		
		io.println(IOHelper.SYNTAXERROR, output);
	}
	private void SyntaxError(Token s) throws Exception {
		String output = "Error : ";
		String spaces = "";
		for(String i : parserList)  {
			output += i + ' ';
		}
		for(int i = 0; i < output.length(); ++i){
			spaces += ' ';
		}
		sc.NextToken();
		output +=  sc.getTokenToString();
		output += '\n'+ spaces +  "^  at this point  ";
		output += "\nError: Expecting [" + s + ']';
		
		
		io.println(IOHelper.SYNTAXERROR, output);
	}
}
