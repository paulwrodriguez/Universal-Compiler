import java.io.IOException;
import java.util.ArrayDeque;

import javax.swing.undo.UndoableEdit;

import Data.Token;


public class Scanner {
	 /*Constants*/
	 /*reserved words*/
	private static final String BEGIN = "BEGIN";
	private static final String READ = "READ";
	private static final String WRITE = "WRITE";
	private static final String END = "END";
	private static final String EofSym = "EofSym";
	
	private static final char LParen = (char)40; 
	private static final char Colon = (char)58; 
	private static final char SemiColon = (char)59; 
	private static final char RParen = (char)41; 
	private static final char Comma = (char)44; 
	private static final char PlusOp = (char)43; 
	private static final char MinusOp = (char)45; 
	private static final char Equals = (char)61; 
	private static final char Dash = MinusOp;
		
	 /*File Characters*/
	private static final char LF = (char)10;
	private static final char CR = (char)13; 
	private static final char SPACE = (char)32; 
	private static final char TAB = (char)9; 
	private static final char Eol = LF;
	
	 /*Public*/ 
	
	 /*Constructor*/
	Scanner(String fileName) throws IOException {
		this.fileName = fileName;
		fr = new FileReader(fileName); // TODO do something if there is an error
	}

	Scanner() {
		// TODO empty constructor for testing. make private later
	}
	
	// Post: Returns next Token in file. 
	public Token Scan() throws Exception 
	{
		 /*Scanner Algorithm*/
		ClearBuffer();
		if(fr.EOF()) {
			return LastToken = Token.EofSym;
		}
		else {
			while (!fr.EOF()) {
				char c = (char)fr.Read();	
				undoBuffer.clear();
				BufferUndoBuffer(c);
				switch(c) {
					case SPACE : 
					case TAB :
					case CR : 
					case LF :
						break;			
					case LParen :
						BufferChar(c);
						return LastToken = Token.LParen;
					case RParen :
						BufferChar(c);
						return LastToken = Token.RParen;
					case SemiColon :
						BufferChar(c);
						return LastToken = Token.SemiColon;
					case Comma :
						BufferChar(c);
						return LastToken = Token.Comma;
					case PlusOp :
						BufferChar(c);
						return LastToken = Token.PlusOp;
					case Colon :
						BufferChar(c);
						if(fr.Inspect() == Equals ) {
							BufferChar((char)fr.Inspect());
							fr.Advance();
							BufferUndoBuffer(Equals);
							return LastToken = Token.AssignOp;
						} 
						else {
							LexicalError(c);
						}
					case Dash :
						if(fr.Inspect() == Dash	) {
							char current = (char)fr.Read();
							while(current != Eol ) {
								// BufferUndoBuffer(current); // TODO this may mess things up
								current = (char) fr.Read();
							}
						}
						else {
							BufferChar(c);
							return LastToken = Token.MinusOp;
						}
						break;
				default: // things that need more processing
						if(Character.toString(c).matches("[A-Za-z]")) {
							BufferChar(c);
							while(!fr.EOF() ) {
								char next = (char) fr.Inspect();
								if(Character.toString(next).matches("[A-Za-z0-9]|[_]")) {
									BufferChar(next);
									BufferUndoBuffer(next);
									fr.Advance();
								}
								else {
									return LastToken = CheckReserved();
								}
							}
							// TODO account of last word case
							return LastToken = CheckReserved();
						}
						else if(Character.toString(c).matches("[0-9]")) {
							BufferChar(c);
							while(!fr.EOF()) {
								char next = (char) fr.Inspect();
								if(Character.toString(next).matches("[0-9]")) {
									BufferChar(next);
									BufferUndoBuffer(next);
									fr.Advance();
								}
								else {
									return LastToken = Token.IntLiteral ;
								}
							}
						}
						else {
							LexicalError(c);
						}
						break;
					}					
			}
		}
		return LastToken = Token.EofSym;
	}

	

	/*Private*/
	private void LexicalError(int errorChar) throws Exception {
		throw new Exception("There was a Lexical Error at " + (char)errorChar);
	}
	private void ClearBuffer() {
		TokenBuffer.clear();
		undoBuffer.clear();
	}
	private void BufferChar(char c) {
		TokenBuffer.addLast(c);
	}
	
	private void BufferUndoBuffer(char c) {
		undoBuffer.addLast(c);
	}
	
	private void UndoScan() {
		Character[] buf = undoBuffer.toArray(new Character[0]);
		for(int i = buf.length-1; i >= 0; --i ) {
			try {
				fr.pushBack(buf[i]);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public Token NextToken() throws Exception {
		Token rtn = Scan();
		UndoScan();
		return rtn;
	}
	
	
	 /* Pre:  Takes identifier in TokenBuffer 
	    Post: Returns the class of TokenBuffer, either ID or some reserved word */
	private Token CheckReserved() {
		String rtn = getTokenToString();
		if(rtn.equals(BEGIN)) 
			return Token.BeginSym;
		else if(rtn.equals(READ))
			return Token.ReadSym;
		else if(rtn.equals(WRITE))
			return Token.WriteSym;
		else if(rtn.equals(END))
			return Token.EndSym;
		else 
			return Token.Id;// should only be variable names
	}
	 
	 /* Post: Returns chars in TokenBuffer to string */
	public String getTokenToString() {
		String rtn = "";
		for(char s : TokenBuffer) {
			rtn = rtn + s;
		}
		if (rtn.equalsIgnoreCase("")){
			rtn = LastToken.name();
		}
		return rtn;
	}
	public void close() throws IOException {
		fr.close();
	}
	
	public Token LastToken() {
		return LastToken;
	}
	 /*Private Data Members */
	
	private String fileName;
	private ArrayDeque<Character> TokenBuffer = new ArrayDeque<Character>();
	private ArrayDeque<Character> undoBuffer = new ArrayDeque<Character>();
	private FileReader fr;
	private Token LastToken;
}
