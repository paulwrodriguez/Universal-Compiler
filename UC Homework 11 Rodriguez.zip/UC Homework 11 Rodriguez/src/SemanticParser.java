import java.util.Vector;

import Data.ExprKind;
import Data.ExprRec;
import Data.OpRec;
import Data.Operator;
import Data.Token;


public class SemanticParser {
	
	 /* Semantic Parser */
	public void Start() {
		// MaxSymbol = 0;
		MaxTemp = 0;
	}
	public void Assign(ExprRec Target, ExprRec Source) {
		Generate("Store ", Extract(Source), Target.name());
	}
	public void ReadId(ExprRec InVar) {
		Generate("Read",InVar.name(), "Integer" );
	}
	public void WriteExpr(ExprRec OutExpr) {
		Generate("Write", Extract(OutExpr), "Integer");
	}
	public ExprRec GenInfix(ExprRec E1, OpRec Op, ExprRec E2) throws Exception {
		ExprRec ERec = new ExprRec(true); // TODO what should be filled with temp data?
		ERec.name = GetTemp();
		
		Generate(ExtractOp(Op), Extract(E1), Extract(E2), ERec.name);
		return ERec;
	}
	public void ProcessId(ExprRec E) throws Exception {
		CheckId(sc.getTokenToString());
		E.kind = ExprKind.IdExpr;
		E.name = sc.getTokenToString();
	}
	public void ProcessLiteral(ExprRec E) {
		E.kind = ExprKind.LiteralExpr;
		E.val = Integer.parseInt(sc.getTokenToString());
	}
	public void ProcessOp(OpRec O) { /*TODO make this return something*/
		if(sc.LastToken() == Token.PlusOp) {
			O.Op = Operator.PlusOp;
		}
		else if(sc.LastToken() == Token.MinusOp) {
			O.Op = Operator.MinusOp;
		}
	}
	public void Finish() {
		Generate("Halt");
	}
	public SemanticParser(IOHelper io, Scanner sc) {
		this.io = io;
		this.sc = sc;
	}
	public void Generate(String ... s) {
		if(s.length == 3) {
			Generate3(s);
		}
		else if(s.length == 4){
			Generate4(s);
		}
		else if(s.length == 1 ) {
			io.pw.println(s[0]);
		}
	}
	public void Generate3(String ... s) {
		io.pw.println("" + s[0] + s[1] + "," + s[2]);
	}
	public void Generate4(String ... s) {
		if(Debugger.DEBUG) {
			io.pw.print("Inside Generate4 with : ");
			for(String i : s) {
				io.pw.println(i);
			}
		}
		io.pw.println("" + s[0] + s[1] + "," + s[2] + "," + s[3]);
	}
	
	public String Extract(ExprRec E) {
		switch(E.Kind()) {
		case IdExpr:
		case TempExpr:
			return E.name;
		case LiteralExpr:
			return E.getVal();
			default:
				System.out.println("There was an error in extract -> " + E.Kind());
				return ""; // TODO should not reach this point
		}
	}
	
	public String ExtractOp(OpRec O) {
		if(O.Op == Operator.PlusOp) {
			return "ADD ";
		}
		else {
			return "SUB ";
		}
	}
	
	public boolean LookUp(String s) {
		boolean UP = false;
		for(int i = 0; i < LastSymbol; ++i) {
			if(SymbolTable[i].equals(s)) {
				UP = true;
			}
		}
		return UP;
	}
	public void Enter(String s) throws Exception {
		if(LastSymbol < MaxSymbol) {
			SymbolTable[LastSymbol] = s;
			LastSymbol++;
		}
		else {
			SymbolTableOverflow();
		}
	}
	public void CheckId(String s) throws Exception {
		if(!LookUp(s)) {
			Enter(s);
			Generate("Declare ", s , "Integer");
		}
	}
	public String GetTemp() throws Exception {
		MaxTemp++;
		String tempName = "Temp&" + MaxTemp;
		CheckId(tempName);
		return tempName;
	}
	private void SymbolTableOverflow() throws Exception {
		Exception e = new Exception("Error: SymbolTableOverFlor: Size -> " + SymbolTable.length);		
		throw e;
	}
	
	/*Private Data Members*/
	private IOHelper io;
	private static final int MaxSymbol = 100;
	private String[] SymbolTable = new String[MaxSymbol];
	private int LastSymbol = 0;
	private int MaxTemp = 0;
	private Scanner sc;
	
}
