UC Homework 04 Rodriguez 09/21/2015


Attached is input and output files. Program reads hw3input.txt file & testDate and outputs to hw4NewScanner(1)(2).txt
file and standard output. Also attached is part 1 of homework in pdf. Attached is also old 
scanner output files. 

I have found a few bugs in my code so this submission is not really
complete. However, this is what I have so far. I need to rework the structure and clean up
the code. 

All files need to me compiled. Homework.java contains main. 