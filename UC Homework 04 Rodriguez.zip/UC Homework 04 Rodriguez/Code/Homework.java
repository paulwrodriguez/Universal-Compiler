import java.io.PrintWriter;

import Data.TokenCode;

public class Homework {

	public static void main(String[] args) throws Exception {
		System.out.println("Start of program");
		hw4();
		System.out.println("End  of prSogram");
	}	
	
	private static void hw4() throws Exception {
		Scanner sc = new Scanner("hw3input.txt");
		PrintWriter pw = new PrintWriter("hw4NewScanner1.txt");
		TokenCode tc = new TokenCode();
		String TokenText = "";
		pw.format("%-10s %-10s\n", "TokenText", "TokenCode");
		while(TokenCode.code != 2) {
			TokenText = sc.Scan(tc, TokenText);
			pw.format("%-10s %-10d\n", TokenText, tc.code);
		}
		sc.close();
		pw.close();
		
		sc = new Scanner("testData.txt");
		pw = new PrintWriter("hw4NewScanner2.txt");
		tc = new TokenCode();
		TokenText = "";
		pw.format("%-10s %-10s\n", "TokenText", "TokenCode");
		while(TokenCode.code != 2) {
			TokenText = sc.Scan(tc, TokenText);
			pw.format("%-10s %-10d\n", TokenText, tc.code);
		}
		
		pw.close();
		sc.close();
	}
}
