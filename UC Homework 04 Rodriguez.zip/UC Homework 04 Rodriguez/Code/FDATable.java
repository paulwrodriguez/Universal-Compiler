package Data;


/*Micro Language Table*/
/* State | Character set classes (ASCII or EBCDIC)
|Letter Digit Blank + � = : , ; ( ) _Tab Eol Other
|
0 1 2 3 14 4 6 17 18 19 20 3 3
1 1 1 11 11 11 11 11 11 11 11 11 1 11 11
2 12 2 12 12 12 12 12 12 12 12 12 12 12 12
3 13 13 3 13 13 13 13 13 13 13 13 13 3 3
4 21 21 21 21 5 21 21 21 21 21 21 21 21
5 5 5 5 5 5 5 5 5 5 5 5 5 5 15 5
6 16
7
8
9
10
11 Id = Letter (Letter | Digit | _)*
12 IntLiteral = Digit+
13 EmptySpace = (Blank | Eol | Tab)+
14 PlusOp
15 Comment = � � Not(Eol)*Eol
16 AssignOp
17 Comma
18 SemiColon
19 LParen
20 Rparen
21 MinusOp */

public class FDATable {
	/* Character Constants*/
	private static final char LF = (char)10;
	private static final char CR = (char)13; 
	private static final char SPACE = (char)32; 
	private static final char TAB = (char)9; 
	private static final char Eol = LF;
	
	public FDATable() {
		this.state = 0;
		this.StartState = 0;
		this.FinalStateRow = 11;
		
	}
	int getIndexFromChar(char c) {
		if(Character.toString(c).matches("[A-Za-z]")) {
			return 0;
		}
		else if(Character.toString(c).matches("[0-9]")) {
			return 1;
		}
		else if(c == ' '){ // TODO make sure this is correct
			return 2;
		}
		else if(c == '+') {
			return 3;
		}
		else if(c == '-' ) {
			return 4;
		}
		else if(c == '=') {
			return 5;
		}
		else if(c == ':'){
			return 6;
		}
		else if(c == ',') {
			return 7;
		}
		else if(c == ';') {
			return 8;
		}
		else if(c == '(') {
			return 9;
		}
		else if(c == ')') {
			return 10;
		}
		else if(c == '_') {
			return 11;
		}
		else if(c == TAB) {
			return 12;
		}
		else if(c == LF || c == CR ) {
			return 13;
		}
		else { // OTHER
			return 14;
		}
		
	}
	public int currentState = 0;
	
	public String [][] TransitionTable = new String[][] {
			{"1", "2",  "3", "14", "4", "",   "6", "17", "18", "19", "20", "", "3", "3", ""},
			{"1", "1", "11", "11","11", "11","11", "11", "11", "11", "11", "1", "11", "11", ""},
			{"12","2", "12", "12","12", "12","12", "12", "12", "12", "12", "12","12", "12", ""},
			{"13","13", "3", "13","13", "13","13", "13", "13", "13", "13", "13","3", "3", ""},
			{"21","21", "21", "21","5", "21","21", "21", "21", "21", "21", "","21", "21", ""},
			{"5","5", "5", "5","5", "5","5", "5", "5", "5", "5", "5","5", "15", "5"},
			{"","", "", "","", "16","", "", "", "", "", "","", "", ""},
			{},
			{},
			{},
			{},
			{"Id"},
			{"IntLiteral"},
			{"EmptySpace"},
			{"PlusOp"},
			{"Comment"},
			{"AssignOp"},
			{"Comma"},
			{"SemiColon"},
			{"LParen"},
			{"RParen"},
			{"MinusOp"},
	};
	public int state ;
	public int StartState;
	public int FinalStateRow;
	private int nextState = 0;
	
	public Actions Action(char c) {
		String s = TransitionTable[state][getIndexFromChar(c)];
		if(Debugger.DEBUG == true) {
			System.out.println("Action: c =  " + c + " | state = " + state + " | transition " + s);
		}
		if(s.equalsIgnoreCase("")) {
			// There was an error 
			return Actions.Error;
		}
		else if(s.matches("\\d+")) {
			// has a next state
			nextState = 0;
			nextState = Integer.parseInt(s);
			switch(nextState) {
			case 1: 
			case 2:
			case 4: 
			case 6:
				return Actions.MoveAppend;
			case 3: 
			case 5:
				return Actions.MoveNoAppend;
			case 15:
			case 17:
				return Actions.HaltNoAppend;
			case 14:
			case 16:
			case 18:
			case 19:
			case 20:
				return Actions.HaltAppend;
			case 11:
			case 12:
			case 13:
			case 21:
				return Actions.HaltReuse;
			default:
				error("ERROR: FDATable.Actions nextState = " + nextState);
				return Actions.Error;
			}
		}
		else {
			error("ERROR: FDATable transition return value  = " + s);
			return Actions.Error;
		}
	}
	private void error(String s) {
		System.out.println(s);
	}
	public boolean isInFinalState(){
		return state >= FinalStateRow;
	}
	private boolean isAFinalState(int index){
		return index >= FinalStateRow;
	}
	public int NextState(int st, char c) {
		String s = TransitionTable[st][getIndexFromChar(c)];
		if(Debugger.DEBUG){
			System.out.println("NextState st " + st + " | c " + c + " | state " + this.state + " | transition " + s);
		}
		return Integer.parseInt(s);
	}
	public String getToken() {
		return TransitionTable[state][nextState];
	}
	public int getTokenCode() {
		return nextState;
	}
	
}
