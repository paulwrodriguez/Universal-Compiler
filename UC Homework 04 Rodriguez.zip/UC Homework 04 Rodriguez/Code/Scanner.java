import java.io.IOException;
import java.util.ArrayDeque;

import Data.Actions;
import Data.FDATable;
import Data.TokenCode;


public class Scanner {
	 /*Constants*/
	 /*reserved words*/
	private static final String BEGIN = "BEGIN";
	private static final String READ = "READ";
	private static final String WRITE = "WRITE";
	private static final String END = "END";
	private static final String EofSym = "EofSym";
	
	private static final char LParen = (char)40; 
	private static final char Colon = (char)58; 
	private static final char SemiColon = (char)59; 
	private static final char RParen = (char)41; 
	private static final char Comma = (char)44; 
	private static final char PlusOp = (char)43; 
	private static final char MinusOp = (char)45; 
	private static final char Equals = (char)61; 
	private static final char Dash = MinusOp;
		
	 /*File Characters*/
	private static final char LF = (char)10;
	private static final char CR = (char)13; 
	private static final char SPACE = (char)32; 
	private static final char TAB = (char)9; 
	private static final char Eol = LF;
	
	 /*Public*/ 
	
	 /*Constructor*/
	Scanner(String fileName) throws IOException {
		fr = new FileReader(fileName); // TODO do something if there is an error
		table = new FDATable();
		currentTokenCode = 4;
	}

	Scanner() {
		// TODO empty constructor for testing. make private later
	}
	
	// Post: Returns next Token in file. 
	public String Scan(TokenCode tokenCode, String TokenText) throws Exception  {
		table.state = table.StartState;
		TokenText = "";
		while (!fr.EOF() && !table.isInFinalState()) {
			switch(Action(table.state, CurrentChar())) {
			case Error:
				System.out.println("ERROR #Do lexical Error Recovery");
				System.exit(-1);
			case MoveAppend:
				table.state = NextState(table.state, CurrentChar());
				TokenText = TokenText + CurrentChar();
				ConsumeChar();
				break;
			case MoveNoAppend:
				table.state = NextState(table.state, CurrentChar());
				ConsumeChar();
				break;
			case HaltAppend:
				tokenCode.code = LoopUpCode(table.state, CurrentChar(), tokenCode.code);
				TokenText = TokenText + CurrentChar();
				tokenCode.code = CheckExceptions(tokenCode.code, TokenText);
				ConsumeChar();
				return TokenText;
			case HaltNoAppend:
				LoopUpCode(table.state, CurrentChar(), tokenCode.code);
				tokenCode.code = CheckExceptions(tokenCode.code, TokenText);
				ConsumeChar();
				if(tokenCode.code == 0) {
					Scan(tokenCode, TokenText);
				}
				return TokenText;
			case HaltReuse:
				tokenCode.code = LoopUpCode(table.state, CurrentChar(), tokenCode.code);
				tokenCode.code = CheckExceptions(tokenCode.code, TokenText);
				if(tokenCode.code == 0){
					Scan(tokenCode, TokenText);
				}
				return TokenText;
			default:
				System.out.println("ERROR: Scan.DefaultCase. Reached Unreachable Code");
				System.exit(-1);
			}
		}
		System.out.println("ERROR: Scan Unreachable Code Segment\n");
		System.exit(-1);
		return null; // ERROR: unreachable
		
	}

	private int CheckExceptions(int tokenCode, String tokenText) {
		if(tokenText.equalsIgnoreCase("begin")){
			return 1;
		}
		else if(tokenText.equalsIgnoreCase("end")){
			return 2;
		}
		else if(tokenText.equalsIgnoreCase("read")){
			return 3;
		}
		else if(tokenText.equalsIgnoreCase("write")){
			return 4;
		}
		else {
			return tokenCode;
		}
		
	}

	private int LoopUpCode(int state, char currentChar, int tokenCode) {
		// Put TokenCode as state
		
		if(state == 15 ) {
			return 0;
		}
		++currentTokenCode;
		return table.getTokenCode();
	}
	private String getToken() {
		return table.getToken();
	}
	private int NextState(int state, char currentChar) {
		return table.NextState(state, currentChar);
	}

	private Actions Action(int state, char c) {
		Actions nextState = table.Action(c);
		return nextState;
	}

	private void ConsumeChar() {
		try {
			fr.Advance();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("ERROR: ConsumeChar Advance");
			e.printStackTrace();
		}
	}

	private char CurrentChar() {
		char c = 0;
		try {
			c = (char) fr.Inspect();
			return c;
		} catch (IOException e) {
			System.out.println("ERROR: currentChar->" + c);
			e.printStackTrace();
			return (char) -1;
		}

	}
	/*{
		
		 Scanner Algorithm
		ClearBuffer();
		if(fr.EOF()) {
			return LastToken = Token.EofSym;
		}
		else {
			while (!fr.EOF()) {
				char c = (char)fr.Read();	
				undoBuffer.clear();
				BufferUndoBuffer(c);
				switch(c) {
					case SPACE : 
					case TAB :
					case CR : 
					case LF :
						break;			
					case LParen :
						return LastToken = Token.LParen;
					case RParen :
						return LastToken = Token.RParen;
					case SemiColon :
						return LastToken = Token.SemiColon;
					case Comma :
						return LastToken = Token.Comma;
					case PlusOp :
						return LastToken = Token.PlusOp;
					case Colon :
						if(fr.Inspect() == Equals ) {
							fr.Advance();
							BufferUndoBuffer(Equals);
							return LastToken = Token.AssignOp;
						} 
						else {
							LexicalError(c);
						}
					case Dash :
						if(fr.Inspect() == Dash	) {
							char current = (char)fr.Read();
							while(current != Eol ) {
								// BufferUndoBuffer(current); // TODO this may mess things up
								current = (char) fr.Read();
							}
						}
						else {
							return LastToken = Token.MinusOp;
						}
						break;
				default: // things that need more processing
						if(Character.toString(c).matches("[A-Za-z]")) {
							BufferChar(c);
							while(!fr.EOF() ) {
								char next = (char) fr.Inspect();
								if(Character.toString(next).matches("[A-Za-z0-9]|[_]")) {
									BufferChar(next);
									BufferUndoBuffer(next);
									fr.Advance();
								}
								else {
									return LastToken = CheckReserved();
								}
							}
							// TODO account of last word case
							return LastToken = CheckReserved();
						}
						else if(Character.toString(c).matches("[0-9]")) {
							BufferChar(c);
							while(!fr.EOF()) {
								char next = (char) fr.Inspect();
								if(Character.toString(next).matches("[0-9]")) {
									BufferChar(next);
									BufferUndoBuffer(next);
									fr.Advance();
								}
								else {
									return LastToken = Token.IntLiteral ;
								}
							}
						}
						else {
							LexicalError(c);
						}
						break;
					}					
			}
		}
		return LastToken = Token.EofSym;
	}*/

	


	/*Private*/
	private void LexicalError(int errorChar) throws Exception {
		throw new Exception("There was a Lexical Error at " + (char)errorChar);
	}
	
	
	public void close() throws IOException {
		fr.close();
	}
	
	 /*Private Data Members */
	
	private FileReader fr;
	private FDATable table;
	private int currentTokenCode;
}
