import java.io.IOException;
import java.io.PrintWriter;

import Data.ExprKind;
import Data.ExprRec;

public class Homework {

	
	public static void main(String[] args) throws Exception {
		System.out.println("Start of program");
		hw3();
		System.out.println("End  of prSogram");
	}	
	
	private static void TestArray() throws IOException {
		Scanner sc = new Scanner("hw3input.txt");
		IOHelper io = new IOHelper(sc, new PrintWriter("hw3output.txt", "UTF-8"), new PrintWriter(System.out));
		io.println(IOHelper.SYS, "Hello world");
		io.close();
	}

	private static void hw3() throws Exception {
		Scanner sc = new Scanner("hw3input.txt");
		IOHelper io = new IOHelper(sc, new PrintWriter("hw3output.txt", "UTF-8"), new PrintWriter(System.out));
		Parser p = new Parser(io);
		p.parse();
		io.close();
		System.out.println("Writing output to hw3output.txt file ...");
	}
	private static void hw2() throws IOException {
		IOHelper io = new IOHelper(new Scanner("hw2Input.txt"), new PrintWriter("hw2output.txt", "UTF-8"));
		Parser p = new Parser(io);
//		p.parse();
		io.close();
	}
	private static void testNextToken() throws Exception {
		Scanner sc = new Scanner("testData.txt");
		FileReader fr = new FileReader("testData.txt");		
		for( int i = 0; i < 59; ++i) {
			System.out.println("Scan -> " +sc.Scan().name());
		}
		System.out.println("Scan -> " + sc.NextToken().name());
	}
	private static void hw1() throws Exception {
		// going to call the scanner on a file that is hardcorded at first
		System.out.println("Start of Scanner Test Program");
		Scanner sc = new Scanner("testData.txt");
		System.out.println("Opening testData.txt file...");
		String rtn = "";
		
		// Open a file. 
		// exit if something goes wrong
		PrintWriter pw = new PrintWriter("output.txt", "UTF-8");
		System.out.println("Opening output.txt file...");
		while (!rtn.equalsIgnoreCase("EofSym"))
		{
			rtn = sc.Scan().name();
			pw.println(rtn);
		}
		System.out.println("Writing to output.txt file...");
		pw.close();
		System.out.println("Closing output.txt file...");
		
		System.out.println("End of Scanner Test Program");
	}

}
