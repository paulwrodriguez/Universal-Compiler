UC Homework 03 Rodriguez 09/07/2015

Attached is input and output files. Program reads hw3input.txt file and outputs to hw3output.txt
file and standard output. I was not able to get the output tabled as it was in lecture notes. 
Currently, function calls output to standard out while compiler assebly output to hw3output.txt. 


All files need to me compiled. Homework.java contains main. 