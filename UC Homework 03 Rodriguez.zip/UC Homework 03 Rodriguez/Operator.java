package Data;

public enum Operator {
PlusOp, MinusOp;
}
