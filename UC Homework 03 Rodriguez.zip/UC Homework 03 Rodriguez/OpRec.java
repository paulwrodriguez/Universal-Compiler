package Data;

public class OpRec {
	public OpRec(Operator O) {
		setOp(O);
	}
	public OpRec() {
		/*TODO do I need to assign default params?*/
	}
	public void setOp(Operator O) {
		Op = O;
	}
	public Operator Op;
}
