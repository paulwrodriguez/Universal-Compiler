import java.io.PrintWriter;

import Data.ExprRec;
import Data.OpRec;


public class Parser {

	private Scanner sc;
	private PrintWriter pw;
	private IOHelper io;
	private SemanticParser sp;
	
	
	Parser(IOHelper io) {
		this.io = io;
		this.sc = io.sc;
		this.pw = io.pw;
		sp = new SemanticParser(this.io, this.sc);
	}

	 /*SystemGoal*/
	private void SystemGoal() throws Exception {
		io.println(IOHelper.SYS,"Call SystemGoals");
		Program();
		Match(Token.EofSym);
		sp.Finish();
	}
	 /*Program*/
	private void Program() throws Exception {
		sp.Start();
		io.println(IOHelper.SYS,"Call Program");
		Match(Token.BeginSym);
		StatementList();
		Match(Token.EndSym);
	}
	 /*StatementList*/
	private void StatementList() throws Exception {
		io.println(IOHelper.SYS,"Call StatementList");
		Statement();
		switch(NextToken()){
		case Id:
		case ReadSym:
		case WriteSym: 
			StatementList();
			break;
			default:
				return;
		}
	}
	 /*Statement*/
	private void Statement() throws Exception{
		/* Semantic Parser Variables */
		ExprRec Identifier = new ExprRec(true);
		ExprRec  Expr = new ExprRec(true);
		switch(NextToken()) {
		case Id:
			io.println(IOHelper.SYS,"Call Statment");
			Ident(Identifier);
			Match(Token.AssignOp);
			Expr = Expression(Expr);
			sp.Assign(Identifier, Expr);
			Match(Token.SemiColon);
			break;
		case ReadSym:
			io.println(IOHelper.SYS,"Call Statment");
			Match(Token.ReadSym);
			Match(Token.LParen);
			IdList();
			Match(Token.RParen);
			Match(Token.SemiColon);
			break;
		case WriteSym:
			io.println(IOHelper.SYS,"Call Statment");
			Match(Token.WriteSym);
			Match(Token.LParen);
			ExprList();;
			Match(Token.RParen);
			Match(Token.SemiColon);
			break;
			default:
				SyntaxError(NextToken());
				break;			
		}
	}
	 /*IdList*/
	private void IdList() throws Exception{
		ExprRec Identifier = new ExprRec(true);
		io.println(IOHelper.SYS,"Call IdList");
		Ident(Identifier);
		sp.ReadId(Identifier);
		if(NextToken() == Token.Comma) {
			Match(Token.Comma);
			IdList();
		}
		else{
			return;
		}
	}
	 /*ExprList*/
	private void ExprList() throws Exception {
		ExprRec Expr = new ExprRec(true);
		io.println(IOHelper.SYS,"Call ExprList");
		Expression(Expr);
		sp.WriteExpr(Expr);
		if(NextToken() == Token.Comma) {
			Match(Token.Comma);
			ExprList();
		}
		else{
			return;
		}
	}
	 /*Expression*/
	private ExprRec Expression(ExprRec Result) throws Exception {
		ExprRec LeftOperand = new ExprRec(true);
		ExprRec RightOperand = new ExprRec(true);
		OpRec Op = new OpRec();
		io.println(IOHelper.SYS,"Call Expression");
		Primary(LeftOperand);
		if(NextToken() == Token.PlusOp || NextToken() == Token.MinusOp) {
			AddOp(Op);
			RightOperand = Expression(RightOperand);
			Result = sp.GenInfix(LeftOperand, Op, RightOperand);
		}
		else {
			Result = LeftOperand;
		}
		return Result; 
	}
	 /*Primary*/
	private void Primary(ExprRec Result) throws Exception{
		switch(NextToken()) {
		case LParen:
			io.println(IOHelper.SYS,"Call Primary");
			Match(Token.LParen);
			Expression(Result);
			Match(Token.RParen);
			break;
		case Id:
			io.println(IOHelper.SYS,"Call Primary");
			Ident(Result);
			break;
		case IntLiteral:
			io.println(IOHelper.SYS,"Call Primary");
			Match(Token.IntLiteral);
			sp.ProcessLiteral(Result);
			break;
			default:
				SyntaxError(NextToken());
				break;
		}
	}
	 /*Ident*/
	private void Ident(ExprRec Result) throws Exception {
		io.println(IOHelper.SYS,"Call Ident");
		Match(Token.Id);
		sp.ProcessId(Result);
	}
	
	 /*AddOp*/
	private void AddOp(OpRec Op){
		switch(NextToken()){
		case PlusOp:
			io.println(IOHelper.SYS,"Call AddOp");
			Match(Token.PlusOp);
			sp.ProcessOp(Op);
			break;
		case MinusOp:
			io.println(IOHelper.SYS,"Call AddOp");
			Match(Token.MinusOp);
			sp.ProcessOp(Op);
			break;
			default:
				SyntaxError(NextToken());
				break;
		}
	}
	private Token NextToken() {
		try {
			return sc.NextToken();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERROR: Parser.nextToken");
			return null;
		}
	}
	public void parse() throws Exception {
		SystemGoal();
	}
	 /*Post: Call SyntaxError if t does not match next token*/
	public void Match(Token expected) {
		Token currentToken;
		io.println(IOHelper.SYS,"Call Match(" + expected.name() + ") ");
		try {
			currentToken = sc.Scan();
			if(currentToken != expected) {
				SyntaxError(currentToken); // Error Correction and Parser Restart
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private void SyntaxError(Token s) {
		System.out.println("Error: Parser.Match -> " + s.name());
	}
}
