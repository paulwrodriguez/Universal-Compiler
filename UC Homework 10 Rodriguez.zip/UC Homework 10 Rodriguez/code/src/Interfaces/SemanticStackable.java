package Interfaces;

public interface SemanticStackable extends ParseStackable {
	
}
