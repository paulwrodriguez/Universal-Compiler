package Data;

public enum Actions {
	Error, 
	MoveAppend, 
	MoveNoAppend, 
	HaltAppend, 
	HaltNoAppend, 
	HaltReuse,
}
