package Data;

public enum TokenConstants {
	READSYM,
	WRITESYM,
	ENDSYM,
	BEGINSYM,
	DECLARESYM, 
	INTEGERSYM
}
