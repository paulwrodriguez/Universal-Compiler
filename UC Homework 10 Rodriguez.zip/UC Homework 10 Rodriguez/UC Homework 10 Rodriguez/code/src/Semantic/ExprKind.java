package Semantic;

public enum ExprKind {
	IdExpr, LiteralExpr, TempExpr;
}
