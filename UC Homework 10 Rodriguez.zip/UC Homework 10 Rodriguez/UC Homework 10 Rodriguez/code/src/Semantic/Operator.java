package Semantic;

/*
 * Define operators here that match the FDA table
 */

public enum Operator {
	PlusOp, MinusOp, AssignOp
}
