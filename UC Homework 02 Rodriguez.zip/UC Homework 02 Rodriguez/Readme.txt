UC Homework 02 Rodriguez 08/31/2015

**NOTE**
I fixed the bug where it would throw an error if eof did not immediately follow END reservered 
word
** **

Attached is input and output files. Program reads hw2input.txt file and outputs to hw2output.txt
file. Output shows the which productions rules were entered and exactly which rule they are. 

example

<production> -> <#>

All files need to me compiled. Homework.java contains main. 