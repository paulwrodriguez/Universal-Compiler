import java.io.PrintWriter;


public class Parser {

	private Scanner sc;
	private PrintWriter pw;
	private IOHelper io;
	
	Parser(IOHelper io) {
		this.io = io;
		this.sc = io.sc;
		this.pw = io.pw;
	}

	 /*SystemGoal*/
	private void SystemGoal() {
		pw.println("<SystemGoals> -> 14");
		Program();
		Match(Token.EofSym);
	}
	 /*Program*/
	private void Program() {
		pw.println("<Program> -> 1");
		Match(Token.BeginSym);
		StatementList();
		Match(Token.EndSym);
	}
	 /*StatementList*/
	private void StatementList() {
		pw.println("<StatementList> -> 2");
		Statement();
		switch(NextToken()){
		case Id:
		case ReadSym:
		case WriteSym: 
			StatementList();
			break;
			default:
				return;
		}
	}
	 /*Statement*/
	private void Statement(){
		switch(NextToken()) {
		case Id:
			pw.println("<Statment> -> 3");
			Ident();
			Match(Token.AssignOp);
			Expression();
			Match(Token.SemiColon);
			break;
		case ReadSym:
			pw.println("<Statment> -> 4");
			Match(Token.ReadSym);
			Match(Token.LParen);
			IdList();
			Match(Token.RParen);
			Match(Token.SemiColon);
			break;
		case WriteSym:
			pw.println("<Statment> -> 5");
			Match(Token.WriteSym);
			Match(Token.LParen);
			ExprList();;
			Match(Token.RParen);
			Match(Token.SemiColon);
			break;
			default:
				SyntaxError(NextToken());
				break;			
		}
	}
	 /*IdList*/
	private void IdList(){
		pw.println("<IdList> -> 6");
		Ident();
		if(NextToken() == Token.Comma) {
			Match(Token.Comma);
			IdList();
		}
		else{
			return;
		}
	}
	 /*ExprList*/
	private void ExprList() {
		pw.println("<ExprList> -> 7");
		Expression();
		if(NextToken() == Token.Comma) {
			Match(Token.Comma);
			ExprList();
		}
		else{
			return;
		}
	}
	 /*Expression*/
	private void Expression() {
		pw.println("<Expression> -> 8");
		Primary();
		if(NextToken() == Token.PlusOp || NextToken() == Token.MinusOp) {
			AddOp();
			Expression();
		}
		else {
			return;
		}
	}
	 /*Primary*/
	private void Primary(){
		switch(NextToken()) {
		case LParen:
			pw.println("<Primary> -> 9");
			Match(Token.LParen);
			Expression();
			Match(Token.RParen);
			break;
		case Id:
			pw.println("<Primary> -> 9");
			Ident();
			break;
		case IntLiteral:
			pw.println("<Primary> -> 11");
			Match(Token.IntLiteral);
			break;
			default:
				SyntaxError(NextToken());
				break;
		}
	}
	 /*Ident*/
	private void Ident() {
		pw.println("<Ident> -> 10");
		Match(Token.Id);
	}
	
	 /*AddOp*/
	private void AddOp(){
		switch(NextToken()){
		case PlusOp:
			pw.println("<AddOp> -> 12");
			Match(Token.PlusOp);
			break;
		case MinusOp:
			pw.println("<AddOp> -> 13");
			Match(Token.MinusOp);
			break;
			default:
				SyntaxError(NextToken());
				break;
		}
	}
	private Token NextToken() {
		try {
			return sc.NextToken();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERROR: Parser.nextToken");
			return null;
		}
	}
	public void parse() {
		SystemGoal();
	}
	 /*Post: Call SyntaxError if t does not match next token*/
	public void Match(Token expected) {
		Token currentToken;
		try {
			currentToken = sc.Scan();
			if(currentToken != expected) {
				SyntaxError(currentToken); // Error Correction and Parser Restart
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private void SyntaxError(Token s) {
		System.out.println("Error: Parser.Match -> " + s.name());
	}
}
