import java.io.PrintWriter;


public class IOHelper {
	public Scanner sc;
	public PrintWriter pw;
	
	IOHelper(Scanner sc, PrintWriter pw) {
		this.sc = sc;
		this.pw = pw;
	}
	
	void close() {
		pw.close();
	}
	
}
