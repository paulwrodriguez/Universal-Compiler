UC Homework 05 Rodriguez 09/29/2015

*Note*
	This is resubmitions. I have corrected number 2. I have not changed part 1 so I know that is wrong. The program
	was correct so I did not change that part either. 
	
Attached is input and output files. Program reads hw5input.txt file & hw5secondgrammer.txt 
and outputs to hw5output.txt. Also attached is hw5writeup which contain question 1 & 2
answers. 



All files need to me compiled. Homework.java contains main. 