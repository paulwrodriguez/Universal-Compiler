/*
 * Author: Paul Rodriguez
 * Grammer Requirements:
 * 	1) Format: <non*terminal> -> [terminal]\s[terminal]<non*terminal> lampda
 * 	2) lampda character must be spelled out
 * 	3) any adjacent terminal symbols must be space seperated
 * 	4) space no required before or after -> or < or >
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import Data.Debugger;


public class GrammerAnalyzer {
	public FileReader fr;
	public BufferedReader bf;
	public Grammer grammer;
	
	
	
	public GrammerAnalyzer(String fileName){
		try {
			fr = new FileReader(fileName);
			bf = new BufferedReader(fr);
			grammer = new Grammer();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("ERROR: GrammerAnalyzer could not open " + fileName);
			System.out.println("Closing Program");
			System.exit(-1);
		}
	}
	public void analyze() throws Exception {
		if( Debugger.DEBUG) {System.out.println("Start of grammer analyzer"); }
		while (bf.ready()) {
			if( Debugger.DEBUG) { System.out.println("--------------"); }
			String[] lines = bf.readLine().split("->");
			if (lines.length != 2) {
				throw new Error(
						"ERROR: Grammer not in proper format. <nonterminal> -> <LHS>");
			}

			// save the LHS of the first terminal
			Production p = new Production();
			p.add(new Symbol(true, false, false, true, lines[0]));
			
			ArrayList<String> items = new ArrayList<String>();
			String current = "";
			boolean terminal = false;
			// parse the RHS
			for (char c : lines[1].toCharArray()) {
				boolean hasChar = Character.toString(c).matches("[a-zA-Z]");
				if (hasChar) {
					current += c;
				} else if (c == '<') {
					if (current.length() > 0) {
						p.add(new Symbol(false, true, true, false, current));
						items.add(current);
						current = "";
					}
					terminal = true;
					current += c;
				} else if (c == ' ') {
					if (current.length() > 0 && !terminal) {
						p.add(new Symbol(false, true, true, false, current));
						items.add(current);
						current = "";
					}
				} else if (c == '>') {
					if (current.length() > 0) {
						current += c;
						p.add(new Symbol(false, true, false, true, current));
						items.add(current);
						current = "";
						terminal = false;
					} else {
						throw new Error(
								"ERROR reading grammer. Cant have > without  first <");
					}
				}else if(hasSpecialCharacter(c)){
					current +=c;
				} else {
					throw new Error("ERROR with reading grammer at: " + c);
				}
				/*
				 * when Letter or character or digit att to current token 
				 * when <
				 * 	if current token length > 0 
				 * 		save current token 
				 * 		clear current
				 * 		token add c to current token 
				 * 	else 
				 * 		add c to current token 
				 * when ' ' 
				 * 	if current token length > 0 
				 * 		save current token 
				 * 		clear current token 
				 * when > 
				 * 	save current token 
				 * 	clear current token
				 */
			}
			if(current.length() > 0){
				p.add(new Symbol(false, true, true, false, current)); // TODO make sure this is right
				items.add(current);
				current = "";
			}
			grammer.add(p);
			if(Debugger.DEBUG){
				print(items);
				System.out.println(p.toString());
			}
		}
		// check for reserved words (i.e. lampda)
		checkExceptions();
	}
	private void checkExceptions() throws Exception{
		int symbolIndex = 0;
		for(int i = 0; i < grammer.size(); ++i){
			symbolIndex = grammer.getProduction(i).contains(new Symbol(false, true, true, false, "lampda"));
			if(symbolIndex > -1){
				grammer.getProduction(i).set(symbolIndex, new Symbol(false, true, false, false, "lampda"));
			}
		}
		return;
	}
	private boolean hasSpecialCharacter(char c) {
		if(c >= (char)33 && c <= (char)126 )
			return true;
		return false;
	}
	private void print(ArrayList<String> items) {
		for(String s : items){
			System.out.println(s);
		}
	}
	
	@Override
	public String toString(){
		return grammer.toString();
	}
	public String getProductionAndSymbolDetails() {
		// TODO Auto-generated method stub
		return grammer.getProductionAndSymbolDetails();
	}
	/* Create Grammer help classes*/
	private class Symbol{
		private boolean LHS;
		private boolean RHS;
		private boolean Terminal;
		private boolean NonTerminal;
		private String text;
		
		public Symbol (){
			LHS = false;
			RHS = false;
			Terminal = false;
			NonTerminal = false;
			setText("");
		}
		public Symbol (boolean lhs, boolean rhs, boolean terminal, boolean nonterminal, String text){
			LHS = lhs;
			RHS = rhs;
			Terminal = terminal;
			NonTerminal = nonterminal;
			setText(text);
		}
		
		public boolean equals(Symbol s){
			if(s.LHS == this.LHS && 
			   s.RHS == this.RHS &&
			   s.NonTerminal == this.NonTerminal &&
			   s.Terminal == this.Terminal &&
			   s.text.equalsIgnoreCase(this.text) ) {
				
				return true; 	
			}
			return false;
		}
		@Override
		public String toString(){
			String rtn = "";
			rtn = "Symbol:"+ text + "\n\tLHS:" + LHS + "\n\tRHS:" + RHS + "\n\tTerminal:" + Terminal + "\n\tNonTerminal:" + NonTerminal;
			return rtn;
		}
		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}
		
		
	}
	private class Production {
		private ArrayList<Symbol> symbols;
		
		public Production(){ symbols = new ArrayList<Symbol>(); }
		
		public void set(int index, Symbol e){
			symbols.set(index, e);
		}


		public void removeSymbol(int symbolIndex) {
			symbols.remove(symbolIndex);
		}


		public int contains(Symbol symbol) {
			int i = 0;
			for(Symbol s : symbols){
				if(s.equals(symbol)){
					return i;
				}
				++i;
			}
			return -1;
		}

		public void add(Symbol s){
			symbols.add(s);
		}
		
		@Override
		public String toString(){
			String rtn = "";
			for(Symbol s : symbols){
				rtn += s.getText();
			}
			return rtn;
		}
		
		public String getListOfSymbolDetails(){
			String rtn = "";
			for(Symbol s : symbols){
				rtn += s.toString() + "\n";
			}
			return rtn;
		}
		
	}
	private class Grammer{
		private ArrayList<Production> productions;
		/*
		 * Getters and Setters
		 */
		public Production getProduction(int index) throws Exception{
			if(productions.size() > index){
				return productions.get(index);
			}else {
				Debugger.ERROR("grammer.getproduction.size < " + index, Debugger.TERMINATE);
				return null;
			}
		}
		public int size(){ return productions.size(); }
		/*
		 * Constructor
		 */
		Grammer(){
			productions = new ArrayList<Production>();
		}
		public String getProductionAndSymbolDetails() {
			String rtn = "";
			int i = 1;
			for(Production p: productions){
				rtn +=i++ + ") " + p.toString();
				rtn += "\n" + p.getListOfSymbolDetails();
			}
			return rtn;
		}
		public void add(Production p){
			productions.add(p);
		}
		@Override
		public String toString(){
			String rtn = "";
			int i = 0;
			for(Production p : productions){
				rtn += ++i +") " + p.toString() + "\n";
				
			}
			return rtn;
		}
	}
	
	
}
