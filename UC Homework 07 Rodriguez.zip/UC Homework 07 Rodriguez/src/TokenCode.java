package Data;

public class TokenCode {
	public TokenCode(){
		code = 0;
	}
	
	public int code;
}
