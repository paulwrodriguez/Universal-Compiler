UC Homework 07 Rodriguez 10/12/2015


Attached is input and output files. Program reads hw7input.txt file and outputs to hw7output.txt.

hw7input.txt contains micro grammar
hw7output.txt contains LL(1) table. 
	in an attempt to avoid spacing confusion, I have printed the table by production 
	and then by cross section in an array-like format. 
	example:
	[<program>][begin] =1
		at the intersection of nonterminal <program> and input begin, go to production 1
	There should be 22 rows as there are 22 productions
	
Contains Java 8 features. 

All files need to me compiled. Homework.java contains main. 