/*
 * Author: Paul Rodriguez
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

import Data.Debugger;
import Data.ErrorException;
import Data.Grammar;
import Data.Production;
import Data.Symbol;
import Data.TermSet;
import Data.TokenCode;
import Data.TokenText;
import Tables.LLTableGen;


public class Parser {
	private Grammar grammar;
	private LLTableGen llTable;
	private ArrayList<TermSet> predictSet;
	private LinkedList<Symbol> stack;
	private Scanner sc;
	private TokenCode tc = new TokenCode();
	private TokenText tt = new TokenText();
	
	Parser(GrammarAnalyzer ga, Scanner sc){
		grammar = ga.getGrammer();
		llTable = new LLTableGen();
		predictSet = ga.getPredictSet();
		try {
			generateLLTable();
		} catch (ErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Debugger.ERRORNOTHROW("generateLLTable failed to run", Debugger.ENDPROGRAM);
		}
		this.sc = sc;
		stack = new LinkedList<Symbol>();
	}
	
	
	public LLTableGen generateLLTable() throws ErrorException{
		if(!llTable.isGenerated()){
			llTable = new LLTableGen(grammar.getAllLHS(), predictSet, grammar.getTerminals());
		}
		llTable.generate();
		return llTable;
	}
	
	// Parse driver
	private void PrettyPrintStatus(String pa, LinkedList<Symbol> ri, String ps){
		String t = "";
		for(Symbol s : ri){
			t =  t + s.getText();
		}
		System.out.format("%1$-15s %2$-20s %3$-20s\n", pa, t, ps );
	}
	public void LLDriver() throws Exception {
		Symbol X = null;
		String a = null;
		LinkedList<Symbol> remInput = new LinkedList<Symbol>();
		String temp = "";
		// setup remaining input stack for output
		while(temp != Scanner.EOFS){
			temp = nextToken();
			remInput.push(new Symbol(false, true, true, false, tt.value));
		}
		remInput.push(new Symbol(false, true, true, false, "$"));
		Collections.reverse(remInput);
		sc.resetScanner();
		// TODO put above in function
		
		Push(grammar.getStarting_symbol());
		String ParseStack = "";
		String ParseAction = "";
		
		for(Symbol s : stack){
			ParseStack += s.getText();
		}
		
		a = nextToken();
		while(!StackEmpty()){
			X = TOP();
			if(X.isNonTerminal()){
				if(T(X,a) > 0){
					Pop();
					Production p = grammar.getProductionByNumber(T(X,a));
					if(Debugger.PARSER)
						System.out.println("pushing " + p.toString());
					for(int i = p.getRHSLength()-1; i >= 0; --i){
						Push(p.getRHSSymbol(i));
					}
					ParseAction = "Predict " + T(X,a);
					ParseStack = "";
					for(Symbol s : stack){
						ParseStack += s.getText();
					}
					PrettyPrintStatus(ParseAction, remInput, ParseStack);
				}
				else{
					Debugger.ERROR("lldriver failed t(X,a)", Debugger.TERMINATE);
				}
			}
			else { // X is a terminal
				if(X.getText().equalsIgnoreCase(a)){
					Pop(); // match of X worked
					ParseAction = "Match " + a;
					ParseStack = "";
					for(Symbol s : stack){
						ParseStack += s.getText();
					}
					remInput.pop();
					PrettyPrintStatus(ParseAction, remInput, ParseStack);
					a = nextToken();
					if(a.equalsIgnoreCase(Scanner.EOFS)){
						Pop();
						remInput.pop();
						PrettyPrintStatus(ParseAction, remInput, ParseStack);
					}
				}
				else{
					Debugger.ERROR("failed match : X != a", Debugger.TERMINATE);
				}
			}
		}
		/*
		 * Push(S); � � Push the Start Symbol onto an empty stack
			while not StackEmpty
			loop
			� � let X be the top stack symbol; let a be the current input token
			if X in nonterminals
				then
				if T(X, a) = X �> Y1Y2. . .Ym
					then
					� � Expand nonterminal, replace X with Y1Y2. . .Ym on the stack.
					� � Begin with Ym, then Ym-1, . . . , and Y1 will be on top of the stack.
					else
					� � process syntax error
				end if;
			else � � X in terminals
				if X = a
					then
					Pop(1); � � Match of X worked
					Scanner(a); � � Get next token
					else
					� � process syntax error
					end if;
				end if;
			end loop;
		 */
		
	}
	
	/*
	 * Helper Functions
	 */
	private void Pop(){
		if(Debugger.PARSER){
			System.out.println("Popping -> " + stack.getFirst().getText());
		}
		stack.pop();
	}
	private int T(Symbol X, String a){
		
		int result = 0;
		result = llTable.getEntry(X, new Symbol(false, true, true, false, a));
		if(Debugger.PARSER){
			System.out.println("t(" + X.getText() + "," + a + ")=" + result);
		}
		return result;
	}
	private String nextToken() throws Exception{
		tc = new TokenCode();
		tt = new TokenText();
		String token = "";
		
		token = sc.Scan(tc, tt);
		if(token == Scanner.EOFS) {
			return Scanner.EOFS;
		}
		if(token.equalsIgnoreCase("id") || token.equalsIgnoreCase("intliteral")){
			return token;
		}
		return tt.value;
	}
	private void Push(Symbol s){
		if(!s.equals(Symbol.LAMPDA)){
			stack.push(s);
		}
		if(Debugger.PARSER){
			System.out.print("stack contains-> {");
			stack.forEach(x->System.out.print(x.getText()+','));
			System.out.println("}");
		}
	}
	
	private boolean StackEmpty(){
		return stack.isEmpty();
	}
	
	private Symbol TOP(){
		return stack.getFirst();
	}
	/*
	 * Helper Functions
	 */


	public LLTableGen getLLTable() {
		return llTable;
	}
}
