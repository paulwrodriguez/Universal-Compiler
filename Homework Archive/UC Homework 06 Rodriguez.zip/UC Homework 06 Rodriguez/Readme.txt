UC Homework 06 Rodriguez 10/05/2015

*Note*
This submission is incomplete. It is mostly working minus a few bugs. At the moment is reads
the grammer and generates fillset and first set correctly with the exception of program and goal in 
first set. Thus, predict are incorrect in those areas. Also I have not finished predict set so that
may also not be correct. I'll resubmit before 07. 
Attached is input and output files. Program reads hw5input.txt file and outputs to hw6output.txt.



All files need to me compiled. Homework.java contains main. 