import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import Data.Debugger;
import Data.MarkedVocabulary;
import Data.Symbol;
import Data.TermSet;
import Data.TokenCode;
import Data.TokenText;

public class Homework {

	public static void main(String[] args) throws Exception {
		System.out.println("*Start of program*\n");
		hw6();
//		mapTest();
		System.out.println("\n*End  of prSogram*");
	}	
	private static void mapTest() {
		HashMap<Symbol, TermSet> firstSet = new HashMap<Symbol, TermSet>();
		HashMap<Symbol, TermSet> second = new HashMap<Symbol, TermSet>();
		Symbol sym = new Symbol(false, false, false, false, "one");
		Symbol sym2 = new Symbol(false, false, false, false, "two");
		Symbol sym3 = new Symbol(false, false, false, false, "three");
		firstSet.put(Symbol.LAMPDA, new TermSet(sym));
		second.put(sym, new TermSet());
		second.put(sym, second.get(sym).add(sym2));
		second.get(sym).add(second.get(sym).setSubstract(sym2));
		second.put(sym, second.get(sym).setSubstract(sym2));
//		second.get(sym).add(sym2);
		second.forEach((k,v) -> System.out.println("key: " + k + " -> value: " + v));
	}
	private static void hw6() throws Exception {
		String firstGrammer = "hw5input.txt";
		String outFile = "hw6output.txt";
		PrintWriter pw = new PrintWriter(outFile);
		System.out.println("First Grammer Analyzed: " + firstGrammer);
		GrammerAnalyzer ga = new GrammerAnalyzer(firstGrammer);
		ga.analyze();
		System.out.println("Writing anaylzed grammer to file: " + outFile + "..." );
		pw.println("**Start of : " + outFile + " grammer**" );
		ga.getPredictSet().forEach((k,v) -> pw.println("" + k.getText() + " -> " + v));
		pw.close();
		if(Debugger.DEBUG){
			Set<Symbol> noDups = new HashSet<Symbol>();
			noDups.addAll(ga.getAllSymbols());
			for(Symbol s : noDups){
				System.out.println(s.toString()+"|");
			}
			System.out.println("---");
			for(Symbol v : ga.getGrammer().getVocabulary()){
				System.out.println(v.getText()+"|");
			}
		}
	}
	private static void hw5() throws Exception {
		// test split function
		String firstGrammer = "hw5input.txt";
		String secondGrammer = "hw5secondgrammer.txt";
		String outFile = "hw5output.txt";
		PrintWriter pw = new PrintWriter(outFile);
		System.out.println("First Grammer Analyzed: " + firstGrammer);
		GrammerAnalyzer ga = new GrammerAnalyzer(firstGrammer);
		ga.analyze();
		System.out.println("Writing anaylzed grammer to file: " + outFile + "..." );
		pw.println("**Start of : " + outFile + " grammer**" );
		pw.println(ga.getProductionAndSymbolDetails());

		
		System.out.println("Second Grammer Analyzed : " + secondGrammer);
		ga = new GrammerAnalyzer(secondGrammer);
		ga.analyze();
		System.out.println("Writing anaylzed grammer to file: " + outFile + "...");
		pw.println("**Start of : " + outFile + " grammer**");
		pw.println(ga.getProductionAndSymbolDetails());
		
		
		pw.close();
		return;
	}
	private static void printArray(Vector<String> a){
		for(String s : a){
			System.out.println(s);
		}
	}
	private static void hw4() throws Exception {
		Scanner sc = new Scanner("hw3input.txt");
		PrintWriter pw = new PrintWriter("hw4NewScanner1.txt");
		
		TokenCode code = new TokenCode();
		TokenText text = new TokenText();
		
		pw.format("%-10s %-10s\n", "TokenText", "TokenCode");
		while(code.code != 2) {
			sc.Scan(code, text);
			pw.format("%-10s %-10d\n", text.value, code.code);
		}
		
		sc.close();
		pw.close();
		
		sc = new Scanner("testData.txt");
		pw = new PrintWriter("hw4NewScanner2.txt");
		code = new TokenCode();
		text = new TokenText();
		
		pw.format("%-10s %-10s\n", "TokenText", "TokenCode");
		while(code.code != 2) {
			sc.Scan(code, text);
			pw.format("%-10s %-10d\n", text.value, code.code);
		}
		
		pw.close();
		sc.close();
	}
}
