package Data;

public class TokenText {
	public TokenText() {
		value = "";
	}
	
	public String value;
}
