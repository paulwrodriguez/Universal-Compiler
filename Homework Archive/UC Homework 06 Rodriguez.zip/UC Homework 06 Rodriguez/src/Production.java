package Data;

import java.util.ArrayList;
import java.util.Objects;


public class Production {
	private ArrayList<Symbol> symbols;
	
	public Production(){ symbols = new ArrayList<Symbol>(); }
	public Production(Production p){
		symbols = new ArrayList<Symbol>();
		symbols.addAll(p.getAllSymbols());
	}
	public Production(ArrayList<Symbol> r){
		symbols = new ArrayList<Symbol>();
		symbols.addAll(r);
	}
	public void set(int index, Symbol e){
		symbols.set(index, e);
	}

	public ArrayList<Symbol> getAllSymbols(){ return symbols; }
	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Production p = (Production) obj;
		boolean result = true;
		if(p.size() != this.symbols.size()){
			result = false;
		}
		else {
			for(int i = 0; i < p.size(); ++i ){
				try {
					result = p.getSymbol(i).equals(this.getSymbol(i));
				} catch (Error e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					try {
						Debugger.ERROR("ERROR: Production.Equals", Debugger.ENDPROGRAM);
					} catch (Error e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				if(result == false){
					break;
				}
			}
		}
		return result;
	}
	@Override
	public int hashCode(){
		return Objects.hash(this.symbols);
	}
	public Symbol getSymbol(int i) throws Data.Error{ 
		if(i > this.size() && i == this.size()){
			Debugger.ERROR("getSymbol index: " + i + " larger then size: " + this.size() , Debugger.TERMINATE);
		} 
		return symbols.get(i);
	}
	private int size() {
		return symbols.size();
	}

	public void removeSymbol(int symbolIndex) {
		symbols.remove(symbolIndex);
	}


	public int contains(Symbol symbol) {
		int i = 0;
		for(Symbol s : symbols){
			if(s.equals(symbol)){
				return i;
			}
			++i;
		}
		return -1;
	}

	public void add(Symbol s){
		symbols.add(s);
	}
	
	@Override
	public String toString(){
		String rtn = "";
		for(Symbol s : symbols){
			rtn += s.getText();
		}
		return rtn;
	}
	
	public String getListOfSymbolDetails(){
		String rtn = "";
		for(Symbol s : symbols){
			rtn += s.toString() + "\n";
		}
		return rtn;
	}
	public int getLHSLength() throws Error{
		if(symbols.size() < 1){
			Debugger.ERROR("production.getLHSLength < 1", Debugger.TERMINATE);
		}
		if(symbols.get(0).isNonTerminal() && !symbols.get(0).isTerminal()){
			return 1;
		}
		else{
			Debugger.ERROR("production.getLHSLength. symbol(0) != terminal || isnonTermainal", Debugger.TERMINATE);
			return -1;
		}
	}
	public int getRHSLength() throws Error{
		if(getLHSLength() != 1){
			Debugger.ERROR("production.getRHSLength ... getLHSLength != 1", Debugger.TERMINATE);
		}
		return symbols.size() - 1;
	}
	/*
	 * Pre: i is between 0 - n
	 * Post: if !0 then throws exception
	 */
	public Symbol getLHSSymbol() throws Error{
		int i = 0; // 0 should always be LHS symbol
		return getSymbol(i);
	}
	/*
	 * Pre: i is inclusive 0 - size -2
	 */
	public Symbol getRHSSymbol(int i) throws Error{
		if(i < 0){
			Debugger.ERROR("getRHSSymbol i < 0", Debugger.TERMINATE);
		}
		// i mapped from 0 - size- 2
		return getSymbol(i + 1); // should error handle
	}

	public ArrayList<Symbol> getRHS() throws Error {
		ArrayList<Symbol> temp = new ArrayList<Symbol>(symbols);
		if(!temp.get(0).isLHS()){
			Debugger.ERROR("production.getRHS != rhs", Debugger.TERMINATE);
		}
		temp.remove(0);
		if(temp.size() == 1){
			if(temp.get(0).equals(Symbol.LAMPDA)){
				temp.remove(0);
			}
		}
		return temp;
	}

	public ArrayList<Symbol> getRHSAfter(int i) {
		ArrayList<Symbol> temp = new ArrayList<Symbol>(this.getAllSymbols());
		if(Debugger.DEBUG){
			if(temp.get(0).isRHS()){
				Debugger.ERRORNOTHROW(" getrhsafter first element is not lhs", Debugger.ENDPROGRAM);
			}
		}
		temp.remove(0); // convert to rhs
		for(int j = 0; j <= i; j++){
			temp.remove(0);
		}
		return temp;
	}
}
