UC Homework 04 Rodriguez 09/29/2015


Attached is input and output files. Program reads hw5input.txt file & hw5secondgrammer.txt 
and outputs to hw5output.txt. Also attached is hw5writeup which contain question 1 & 2
answers. 



All files need to me compiled. Homework.java contains main. 