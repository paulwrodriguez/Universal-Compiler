import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.Collections;
import java.util.Vector;

import Data.TokenCode;
import Data.TokenText;

public class Homework {

	public static void main(String[] args) throws Exception {
		System.out.println("*Start of program*\n");
		hw5();
		System.out.println("\n*End  of prSogram*");
	}	
	private static void hw5() throws Exception {
		// test split function
		String firstGrammer = "hw5input.txt";
		String secondGrammer = "hw5secondgrammer.txt";
		String outFile = "hw5output.txt";
		PrintWriter pw = new PrintWriter(outFile);
		System.out.println("First Grammer Analyzed: " + firstGrammer);
		GrammerAnalyzer ga = new GrammerAnalyzer(firstGrammer);
		ga.analyze();
		System.out.println("Writing anaylzed grammer to file: " + outFile + "..." );
		pw.println("**Start of : " + outFile + " grammer**" );
		pw.println(ga.getProductionAndSymbolDetails());

		
		System.out.println("Second Grammer Analyzed : " + secondGrammer);
		ga = new GrammerAnalyzer(secondGrammer);
		ga.analyze();
		System.out.println("Writing anaylzed grammer to file: " + outFile + "...");
		pw.println("**Start of : " + outFile + " grammer**");
		pw.println(ga.getProductionAndSymbolDetails());
		
		
		pw.close();
		return;
	}
	private static void printArray(Vector<String> a){
		for(String s : a){
			System.out.println(s);
		}
	}
	private static void hw4() throws Exception {
		Scanner sc = new Scanner("hw3input.txt");
		PrintWriter pw = new PrintWriter("hw4NewScanner1.txt");
		
		TokenCode code = new TokenCode();
		TokenText text = new TokenText();
		
		pw.format("%-10s %-10s\n", "TokenText", "TokenCode");
		while(code.code != 2) {
			sc.Scan(code, text);
			pw.format("%-10s %-10d\n", text.value, code.code);
		}
		
		sc.close();
		pw.close();
		
		sc = new Scanner("testData.txt");
		pw = new PrintWriter("hw4NewScanner2.txt");
		code = new TokenCode();
		text = new TokenText();
		
		pw.format("%-10s %-10s\n", "TokenText", "TokenCode");
		while(code.code != 2) {
			sc.Scan(code, text);
			pw.format("%-10s %-10d\n", text.value, code.code);
		}
		
		pw.close();
		sc.close();
	}
}
