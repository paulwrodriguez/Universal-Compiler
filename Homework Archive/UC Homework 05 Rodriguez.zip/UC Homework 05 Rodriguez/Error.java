package Data;

public class Error extends Exception{
	private String m;
	public Error(String m){
		this.m = m;
	}
	public Error(String m, int code){
		this.m = m;
	}
	@Override
	public String getMessage(){ return this.m; 	}
}
