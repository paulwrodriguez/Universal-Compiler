package Data;

import java.util.Objects;


public class Symbol{
	public static final Symbol LAMPDA = new Symbol(false, true, false, false, "lampda");
	public static final Symbol EMPTYSET = new Symbol(false, false, false, false, "emptySet");
	private boolean LHS;
	private boolean RHS;
	private boolean Terminal;
	public boolean isLHS() {
		return LHS;
	}
	public void setLHS(boolean lHS) {
		LHS = lHS;
	}
	public boolean isRHS() {
		return RHS;
	}
	public void setRHS(boolean rHS) {
		RHS = rHS;
	}
	public boolean isTerminal() {
		return Terminal;
	}
	public void setTerminal(boolean terminal) {
		Terminal = terminal;
	}
	public boolean isNonTerminal() {
		return NonTerminal;
	}
	public void setNonTerminal(boolean nonTerminal) {
		NonTerminal = nonTerminal;
	}

	private boolean NonTerminal;
	private String text;
	
	public Symbol (){
		LHS = false;
		RHS = false;
		Terminal = false;
		NonTerminal = false;
		setText("");
	}
	public void test(){
		Symbol temp = new Symbol(true, false, false,false, "test");
		int one = temp.hashCode();
		temp = new Symbol(true, false, false, false, "test");
		int two = temp.hashCode();
		System.out.println(one + " " + two);
		
	}
	public Symbol (boolean lhs, boolean rhs, boolean terminal, boolean nonterminal, String text){
		LHS = lhs;
		RHS = rhs;
		Terminal = terminal;
		NonTerminal = nonterminal;
		setText(text);
	}
	
	@Override
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Symbol other = (Symbol) obj;

		if(other.LHS == this.LHS && 
				other.RHS == this.RHS &&
				other.NonTerminal == this.NonTerminal &&
				other.Terminal == this.Terminal &&
				other.text.equalsIgnoreCase(this.text) ) {
			return true; 	
		}
		else if( other.text.equalsIgnoreCase(this.text) &&
				other.NonTerminal == this.NonTerminal &&
				other.Terminal == this.Terminal ){
			if(other.LHS == this.RHS || other.RHS == this.LHS){
				return true;
			}
		}
		return false;
	}
	@Override
	public int hashCode() {
		return Objects.hash(this.text);
	}
	@Override
	public String toString(){
		String rtn = "";
		rtn = "Symbol:"+ text + "\n\tLHS:" + LHS + "\n\tRHS:" + RHS + "\n\tTerminal:" + Terminal + "\n\tNonTerminal:" + NonTerminal;
		return rtn;
	}
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
}