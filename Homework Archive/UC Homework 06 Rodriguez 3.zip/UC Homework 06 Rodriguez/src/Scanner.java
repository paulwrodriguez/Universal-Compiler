import java.io.IOException;

import Data.Actions;
import Data.FDATable;
import Data.TokenCode;
import Data.TokenText;


public class Scanner {
	 /*Constants*/
	 /*reserved words*/
	private static final String BEGIN = "BEGIN";
	private static final String READ = "READ";
	private static final String WRITE = "WRITE";
	private static final String END = "END";
	private static final String EofSym = "EofSym";
	
	private static final char LParen = (char)40; 
	private static final char Colon = (char)58; 
	private static final char SemiColon = (char)59; 
	private static final char RParen = (char)41; 
	private static final char Comma = (char)44; 
	private static final char PlusOp = (char)43; 
	private static final char MinusOp = (char)45; 
	private static final char Equals = (char)61; 
	private static final char Dash = MinusOp;
		
	 /*File Characters*/
	private static final char LF = (char)10;
	private static final char CR = (char)13; 
	private static final char SPACE = (char)32; 
	private static final char TAB = (char)9; 
	private static final char Eol = LF;
	
	 /*Public*/ 
	
	 /*Constructor*/
	Scanner(String fileName) throws IOException {
		fr = new FileReader(fileName); // TODO do something if there is an error
		table = new FDATable();
	}

	Scanner() {
		// TODO empty constructor for testing. make private later
	}
	
	public void Pass(TokenCode tCode, TokenText tText) {
		tCode.code = 5;
		tText.value = "hello world";
		return;
		
	}
	// Post: Returns next Token in file. 
	public void Scan(TokenCode tokenCode, TokenText tokenText) throws Exception  {
		table.state = table.StartState;
		tokenText.value = "";
		while (!table.isInFinalState() && !EOF()) {
			switch(Action(table.state, CurrentChar())) {
			case Error:
				System.out.println("ERROR #Do lexical ErrorException Recovery");
				System.exit(-1);
			case MoveAppend:
				table.state = NextState(table.state, CurrentChar());
				tokenText.value = tokenText.value + CurrentChar();
				ConsumeChar();
				break;
			case MoveNoAppend:
				table.state = NextState(table.state, CurrentChar());
				ConsumeChar();
				break;
			case HaltAppend:
				LoopUpCode(table.state, CurrentChar(), tokenCode);
				tokenText.value = tokenText.value + CurrentChar();
				CheckExceptions(tokenCode, tokenText);
				ConsumeChar();
				return ;
			case HaltNoAppend:
				LoopUpCode(table.state, CurrentChar(), tokenCode);
				CheckExceptions(tokenCode, tokenText);
				ConsumeChar();
				if(tokenCode.code == 0) {
					Scan(tokenCode, tokenText);
				}
				return ;
			case HaltReuse:
				LoopUpCode(table.state, CurrentChar(), tokenCode);
				CheckExceptions(tokenCode, tokenText);
				if(tokenCode.code == 0){
					Scan(tokenCode, tokenText);
				}
				return; 
			default:
				System.out.println("ERROR: Scan.DefaultCase. Reached Unreachable Code");
				System.exit(-1);
			}
		}
		// error condition 
		tokenCode.code = -1;
		return ;
		
	}

	private boolean EOF() throws IOException {
		if(fr.Inspect() == -1){
			return true; // EOF has been reached
		}
		else {
			return false;
		}
	}

	private void CheckExceptions(TokenCode tokenCode, TokenText tokenText) {
		if(tokenText.value.equalsIgnoreCase("begin")){
			tokenCode.code = 1;
			return;
		}
		else if(tokenText.value.equalsIgnoreCase("end")){
			tokenCode.code = 2;
			return;
		}
		else if(tokenText.value.equalsIgnoreCase("read")){
			tokenCode.code = 3;
			return;
		}
		else if(tokenText.value.equalsIgnoreCase("write")){
			tokenCode.code = 4;
			return;
		}
		else {
			return;
		}	
	}

	private void LoopUpCode(int state, char currentChar, TokenCode tokenCode) {
		// Put TokenCode as state
		
		if(state == 15 ) {
			tokenCode.code = 0;
			return;
		}
		tokenCode.code = table.getTokenCode();
		return;
	}
	private String getToken() {
		return table.getToken();
	}
	private int NextState(int state, char currentChar) {
		return table.NextState(state, currentChar);
	}

	private Actions Action(int state, char c) {
		Actions nextState = table.Action(c);
		return nextState;
	}

	private void ConsumeChar() {
		try {
			fr.Advance();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("ERROR: ConsumeChar Advance");
			e.printStackTrace();
		}
	}

	private char CurrentChar() {
		char c = 0;
		try {
			c = (char) fr.Inspect();
			return c;
		} catch (IOException e) {
			System.out.println("ERROR: currentChar->" + c);
			e.printStackTrace();
			return (char) -1;
		}

	}


	/*Private*/
	private void LexicalError(int errorChar) throws Exception {
		throw new Exception("There was a Lexical ErrorException at " + (char)errorChar);
	}
	
	
	public void close() throws IOException {
		fr.close();
	}
	
	 /*Private Data Members */
	
	private FileReader fr;
	private FDATable table;
}
