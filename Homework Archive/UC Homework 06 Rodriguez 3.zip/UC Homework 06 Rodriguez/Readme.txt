UC Homework 06 Rodriguez 10/05/2015


*Note* This is the revised submission for hw6

Attached is input and output files. Program reads hw6input.txt/hw5input.txt file and outputs to hw6output.txt/hw6output2.txt.

hw6input.txt contains homework 2b grammar
hw6output.txt contains predict set for this grammar by production
hw5input.txt contains micro grammar 
hw6output2.txt file contains predict set for micro grammar by production

Program contains java 8 features. 

All files need to me compiled. Homework.java contains main. 