package Semantic;

public class OpRec {

}
