package Semantic;

public enum SemanticRecordKind {
	OpRec, ExprRec, Error
}
