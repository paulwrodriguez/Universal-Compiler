package Semantic;

public class ExprRec {
	public ExprType Kind;
}
